from torch import nn
from modelsHGNN import HGNN_conv
import torch.nn.functional as F


class HGNN(nn.Module):
    def __init__(self, in_ch, n_class, n_hid, dropout=0.5):
        super(HGNN, self).__init__()
        self.dropout = dropout
        self.hgc1 = HGNN_conv(in_ch, n_hid)
        self.hgc2 = HGNN_conv(n_hid, n_class)

    def forward(self, x, G):
        # x = F.relu(self.hgc1(x, G))
        # x = F.dropout(x, self.dropout)
        # x = self.hgc2(x, G)
        x = self.hgc1(x, G)
        x = F.relu(x)
        x = F.dropout(x, self.dropout)
        x = self.hgc2(x, G)
        x = F.relu(x)
        x = F.dropout(x, self.dropout)
        return x
